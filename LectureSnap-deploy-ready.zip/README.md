# LectureSnap

Paste a permitted YouTube lecture URL and export the important whiteboard states as a PDF.

## Run locally (Windows)

1. Install Python 3.11 or newer.
2. Open a terminal in this folder.
3. Run `python -m venv .venv`.
4. Run `.venv\Scripts\pip install -r requirements.txt`.
5. Double-click `start-lecturesnap.bat`.

Use the app only for lectures you own or have permission to process.

## What it does

- Finds final whiteboard or slide states from a YouTube lecture.
- Filters empty and near-duplicate boards.
- Generates one landscape A4 PDF with one board image per page.
- Includes a dark-mode slider.

The presenter-removal setting is optional. It can fill a temporarily covered whiteboard area only when that area is visible in nearby frames; it does not invent blocked writing.

## Deploy on Render

1. Create a GitHub repository and upload these project files (not the `jobs` folder).
2. In Render, choose **New +** then **Blueprint** and select that repository.
3. Render reads `render.yaml`; choose **Apply** to deploy.

The free plan is useful for a prototype. Long lecture processing can take time, so a paid worker or background-job system is recommended before sharing it widely.
