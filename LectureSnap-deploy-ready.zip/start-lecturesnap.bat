@echo off
start "LectureSnap server - keep this window open" /D "%~dp0" "%ComSpec%" /k run-server.bat
timeout /t 2 /nobreak >nul
start "" http://127.0.0.1:5050
