@echo off
set "APP_DIR=%~dp0"
set "PYTHON_EXE=%APP_DIR%.venv\Scripts\python.exe"
if not exist "%PYTHON_EXE%" set "PYTHON_EXE=%APP_DIR%..\..\work\lecturesnap-venv\Scripts\python.exe"
if not exist "%PYTHON_EXE%" (
  echo LectureSnap has not been set up on this computer yet.
  echo Read README.md and create .venv first, then run this file again.
  pause
  exit /b 1
)
echo Starting LectureSnap at http://127.0.0.1:5050
echo Keep this window open while you use the app.
"%PYTHON_EXE%" "%APP_DIR%app.py"
pause
